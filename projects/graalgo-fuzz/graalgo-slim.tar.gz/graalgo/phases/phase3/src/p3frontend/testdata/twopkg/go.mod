module example.com/twopkg

go 1.27
