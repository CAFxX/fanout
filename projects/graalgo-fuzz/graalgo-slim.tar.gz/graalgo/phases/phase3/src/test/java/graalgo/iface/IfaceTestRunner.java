package graalgo.iface;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal red-green test runner (mirrors Phase-1 {@code graalgo.test.Runner}
 * and Phase-2 {@code SchedTestRunner}): instantiates each registered test
 * class and invokes every public no-arg method whose name starts with
 * "test". Exits 0 on all-pass, 1 on any failure. New test classes register
 * in TESTS below.
 */
public final class IfaceTestRunner {
    private static final List<Class<?>> TESTS = new ArrayList<>();

    static {
        TESTS.add(IfaceDispatchNodeTest.class);
        TESTS.add(IfaceMethodTablesTest.class);
        TESTS.add(graalgo.frontend.DescriptorNamesTest.class);
        TESTS.add(LinknameTest.class);
        TESTS.add(ItabForIntrinsicTest.class);
        TESTS.add(AtomicContentionTest.class);
        TESTS.add(graalgo.p3sync.launcher.LinknameEndToEndTest.class);
        TESTS.add(graalgo.p3time.TimeChanLenCapTest.class);
        TESTS.add(graalgo.frontend.ChanBuilderTest.class);
        // P3-M8 (wave 2): the GoOs errno-mapper + intrinsic unit tests.
        TESTS.add(graalgo.p3os.GoOsErrnoTest.class);
        // P3-M8 (reviewer-2 P1-4/P1-5): reflect TypeInfo build pins.
        TESTS.add(graalgo.p3reflect.ReflectTypesTest.class);
        // P3-M9 (RISK-M9-1/RISK-M9-2): netpoller + socket traps.
        TESTS.add(graalgo.p3net.GoNetpollTest.class);
    }

    private IfaceTestRunner() {}

    public static void main(String[] args) {
        int run = 0;
        int failed = 0;
        List<String> failures = new ArrayList<>();
        for (Class<?> tc : TESTS) {
            Object inst;
            try {
                inst = tc.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                throw new RuntimeException("cannot instantiate " + tc.getName(), e);
            }
            for (Method m : tc.getDeclaredMethods()) {
                if (!m.getName().startsWith("test") || m.getParameterCount() != 0
                        || !Modifier.isPublic(m.getModifiers())) {
                    continue;
                }
                run++;
                String name = tc.getSimpleName() + "." + m.getName();
                try {
                    m.invoke(inst);
                    System.out.println("PASS " + name);
                } catch (Exception e) {
                    failed++;
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    failures.add(name + ": " + cause);
                    System.out.println("FAIL " + name + ": " + cause);
                }
            }
        }
        System.out.println(run + " tests, " + failed + " failures");
        if (failed > 0) {
            for (String f : failures) {
                System.out.println("  " + f);
            }
            System.exit(1);
        }
    }
}
