package main

import "net"

func main() {
	println("imports are out of v1 scope")
}
