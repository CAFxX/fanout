package graalgo.jfr;

import graalgo.sched.GoroutineHandle;

/**
 * Central JFR emission point for scheduler observability (P2-M6, WS F;
 * GG-0008 JFR slice).
 *
 * <p>Overhead contract: when no recording has our events enabled, the
 * park path costs tens of nanoseconds (two volatile field accesses and
 * one {@code Event.isEnabled()} at ~8ns — measured on GraalVM 25.0.4.1.1,
 * not the ~600ns an early flawed probe reported; the caching layer built
 * on that number was removed in review) — no allocation, no
 * {@code System.nanoTime()}, no JFR call. Start/end/block emissions check
 * the live JFR state directly — they are not hot-path.
 *
 * <p>Rate contract: {@code graalgo.GoroutinePark} is committed for
 * non-quantum parks lasting at least {@link #PARK_THRESHOLD_NANOS}, and
 * for 1-in-1024 sampled quantum parks (the hot loop — a duration
 * threshold cannot filter it: measured 26% of quantum parks exceed
 * 100µs). {@code graalgo.ChannelBlock} fires only when an operation
 * actually blocks; non-blocking fast-path channel ops emit nothing.
 *
 * <p>Opt-in: all graalgo events are {@code @Enabled(false)} — a bare
 * {@code new Recording()} does <em>not</em> capture them (JFR would
 * otherwise enable custom events by default for any active recording).
 * Enable explicitly: {@code rec.enable("graalgo.GoroutineStart")} etc.
 * For a live JVM: {@code jcmd <pid> JFR.start name=graalgo
 * '+graalgo.GoroutineStart#enabled=true' '+graalgo.GoroutineEnd#enabled=true'
 * '+graalgo.GoroutinePark#enabled=true' '+graalgo.ChannelBlock#enabled=true'}.
 */
public final class JfrEvents {
    private JfrEvents() {}

    /**
     * Parks shorter than this are not committed as
     * {@code graalgo.GoroutinePark} events. Default 100&nbsp;µs:
     * quantum-park round-trips measure single-digit microseconds, so the
     * scheduler hot loop stays silent, while channel/timer/select blocks
     * (milliseconds) are recorded. Override with
     * {@code -Dgraalgo.jfr.parkThresholdNanos=<nanos>}.
     */
    public static final long PARK_THRESHOLD_NANOS =
            Long.getLong("graalgo.jfr.parkThresholdNanos", 100_000L);

    /**
     * Emitted-but-dropped count (observability must never break the
     * scheduler: emission failures are swallowed and counted, never
     * propagated). Test-visible.
     */
    private static final java.util.concurrent.atomic.AtomicLong droppedEmits =
            new java.util.concurrent.atomic.AtomicLong();

    /** Number of swallowed emission failures since VM start. */
    public static long droppedEmits() {
        return droppedEmits.get();
    }

    /**
     * Runs an emission, swallowing failures. JFR commit is designed not
     * to throw, but these call sites are scheduler-critical (awaitAck,
     * spawn finally, channel ops): a throwing observability hook must
     * never break scheduling or mask the goroutine's real exception.
     */
    private static void emitQuietly(Runnable emit) {
        try {
            emit.run();
        } catch (RuntimeException e) {
            droppedEmits.incrementAndGet();
        }
    }

    /**
     * Force-initializes the event classes so {@code Recording.enable(name)}
     * resolves them and, critically, so the one-time
     * {@code FlightRecorder.register} happens here on the startup thread,
     * never lazily on a goroutine carrier. The pre-fix pin stacks show
     * {@code register} ← {@code <clinit>} on carriers (the exact
     * park-while-pinned site inside JFR init is racy and unidentified —
     * reviewer1 P2-7 — but forcing {@code <clinit>} here eliminates the
     * whole class). Class literals alone do NOT initialize (JLS 12.4.1);
     * each event class declares its own {@code enabled()} touching the
     * subclass-static prototype, which forces {@code <clinit>}.
     *
     * <p>Must be called once at scheduler startup, before the first spawn.
     */
    public static void ensureRegistered() {
        // Each enabled() touches the event class's own static prototype,
        // forcing <clinit> (which registers with JFR). The events are
        // @Enabled(false) so the results are always false; the return
        // values are discarded — the class-initialization side effect is
        // the entire point. Stored in an array so a dropped call is a
        // compile error, not a silent no-op.
        boolean[] initialized = {
            GoroutineStartEvent.enabled(),
            GoroutineEndEvent.enabled(),
            GoroutineParkEvent.enabled(),
            ChannelBlockEvent.enabled(),
        };
        if (initialized.length != 4) {
            throw new AssertionError("event registration list changed");
        }
    }

    /** True if any graalgo event is enabled in any active recording. */
    public static boolean anyEnabled() {
        return GoroutineStartEvent.enabled()
                || GoroutineEndEvent.enabled()
                || GoroutineParkEvent.enabled()
                || ChannelBlockEvent.enabled();
    }

    /** Goroutine started executing (call after first admission). */
    public static void goroutineStart(GoroutineHandle h) {
        if (GoroutineStartEvent.enabled()) {
            Thread t = h.thread;
            String name = t == null ? "" : t.getName();
            emitQuietly(() -> GoroutineStartEvent.emit(h.id, name));
        }
    }

    /** Goroutine finished (call in the vthread finally block). */
    public static void goroutineEnd(GoroutineHandle h, long lifetimeNanos) {
        if (GoroutineEndEvent.enabled()) {
            emitQuietly(() -> GoroutineEndEvent.emit(h.id, lifetimeNanos));
        }
    }

    /**
     * Quantum-park sampling (P2-M6 rate control): quantum parks are the
     * scheduler hot loop (tens of microseconds each — a 100µs duration
     * threshold does NOT filter them; measured 26% exceed it). Committing
     * every one would drown the recording, so 1-in-1024 is sampled. The
     * sampled events carry true durations, so the distribution stays
     * observable. Non-quantum parks use the duration threshold instead.
     */
    private static final long QUANTUM_SAMPLE_MASK = 1023L;

    /**
     * Records that {@code h} is parking for {@code reason}. Call before
     * the park becomes visible (same place as {@code armPark}).
     * The start timestamp is only taken when a recording might want the
     * event, keeping the disabled path to a few nanoseconds.
     */
    public static void notePark(GoroutineHandle h, ParkReason reason) {
        h.parkReason = reason;
        h.parkStartNanos = GoroutineParkEvent.enabled() ? System.nanoTime() : 0L;
    }

    /**
     * Called when a park's {@code awaitAck} returns. Commits
     * {@code graalgo.GoroutinePark} for non-quantum parks lasting at
     * least {@link #PARK_THRESHOLD_NANOS}, and for 1-in-1024 quantum
     * parks (sampled). Consumes the parked reason (idempotent per park).
     * A zero start timestamp means the park began while disabled —
     * duration unknown, nothing committed.
     */
    public static void parkResumed(GoroutineHandle h) {
        ParkReason reason = h.parkReason;
        if (reason == null) {
            return;
        }
        h.parkReason = null;
        long start = h.parkStartNanos;
        if (start == 0L || !GoroutineParkEvent.enabled()) {
            return;
        }
        long durationNanos = System.nanoTime() - start;
        if (reason == ParkReason.QUANTUM) {
            if ((h.parkSeq.get() & QUANTUM_SAMPLE_MASK) != 0) {
                return;
            }
        } else if (durationNanos < PARK_THRESHOLD_NANOS) {
            return;
        }
        emitQuietly(() -> GoroutineParkEvent.emit(h.id, reason, durationNanos));
    }

    /** A channel operation blocked (call before parking). */
    public static void channelBlock(GoroutineHandle h, long channelId, ChannelOp op) {
        if (ChannelBlockEvent.enabled()) {
            emitQuietly(() -> ChannelBlockEvent.emit(h.id, channelId, op));
        }
    }

    /**
     * Begins the blocking-I/O interval event (call at {@code ioEnter}).
     * Returns null when disabled at enter — {@link #ioParkEnd} then
     * falls back to the emit-at-exit path, so a recording started
     * mid-syscall still observes the interval. One allocation on the
     * non-hot I/O path.
     */
    public static GoroutineParkEvent ioParkBegin() {
        return GoroutineParkEvent.enabled() ? GoroutineParkEvent.beginInterval() : null;
    }

    /**
     * Ends the blocking-I/O interval (call at {@code ioExit}). A begun
     * interval commits with the JFR interval spanning the syscall
     * (reviewer2 P2-7); otherwise the emit-at-exit fallback reports the
     * full duration. Below-threshold intervals are discarded.
     */
    public static void ioParkEnd(GoroutineHandle h, GoroutineParkEvent begun, long ioNanos) {
        if (begun != null) {
            if (ioNanos >= PARK_THRESHOLD_NANOS) {
                long id = h.id;
                emitQuietly(() -> begun.commitInterval(id, ParkReason.IO.name(), ioNanos));
            }
            return;
        }
        ioBlocked(h, ioNanos);
    }

    /**
     * A blocking-I/O interval finished while no interval was begun
     * (recording started mid-syscall): emit at exit with the full
     * duration. Not rate-sampled — I/O syscalls are not the hot loop.
     */
    private static void ioBlocked(GoroutineHandle h, long ioNanos) {
        if (GoroutineParkEvent.enabled() && ioNanos >= PARK_THRESHOLD_NANOS) {
            emitQuietly(() -> GoroutineParkEvent.emit(h.id, ParkReason.IO, ioNanos));
        }
    }
}
