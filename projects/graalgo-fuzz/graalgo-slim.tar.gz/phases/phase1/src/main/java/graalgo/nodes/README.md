# graalgo.nodes

Reserved for WS E/F control-flow nodes (if/for/switch, go/defer/panic).
Expression nodes stay in `graalgo.frontend` per `docs/frontend-v1.md`
§9.6 — do not move `BinaryOpNode`/`UnaryOpNode`/`ConstNode`/`ConvertNode`
here.
