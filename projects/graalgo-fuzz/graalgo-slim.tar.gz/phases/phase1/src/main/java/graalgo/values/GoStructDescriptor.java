package graalgo.values;

import java.util.List;

/**
 * Descriptor for a Go struct type (D5): the field layout used by
 * {@link GoStruct}.
 *
 * <p>Fields of primitive kinds ({@code long} carriers: all int/uint kinds;
 * {@code int} carriers: none yet — sub-64 ints live in {@code long[]}
 * too until WS D specializes; {@code float}/{@code double}/
 * {@code boolean} go to {@code longs[]} as bit patterns… ) — the exact
 * split is: every field whose value fits the {@code long[]} carrier by the
 * D5 mapping's primitive set goes to {@code longs} (ints as raw bits,
 * floats as {@code Float.floatToIntBits}/{@code Double.doubleToLongBits},
 * bools as 0/1); everything else (strings, slices, maps, nested structs,
 * pointers, interfaces, funcs) goes to {@code objects}. The descriptor is
 * built once per struct type from the frontend type table; field access
 * nodes (WS D) index through it.
 */
public final class GoStructDescriptor {
    /**
     * One field's placement. arrayLen is the array length for ARRAY-kind
     * fields (-1 for non-arrays); arrayElemKind is the element kind for
     * ARRAY-kind fields (null for non-arrays). Used by GoStruct.zero to
     * pre-allocate array fields (Go: new(T) gives zero-valued arrays, not null).
     */
    public record Field(String name, GoKind kind, boolean inLongs, int index, int arrayLen, GoKind arrayElemKind) {}

    private final String typeName;
    private final List<Field> fields;
    private final int longsCount;
    private final int objectsCount;

    public GoStructDescriptor(String typeName, List<Field> fields) {
        this.typeName = typeName;
        this.fields = List.copyOf(fields);
        int longs = 0;
        int objects = 0;
        for (Field f : fields) {
            if (f.inLongs()) {
                if (f.index() != longs) {
                    throw new IllegalArgumentException("longs index out of order for field " + f.name());
                }
                longs++;
            } else {
                if (f.index() != objects) {
                    throw new IllegalArgumentException("objects index out of order for field " + f.name());
                }
                objects++;
            }
        }
        this.longsCount = longs;
        this.objectsCount = objects;
    }

    /**
     * Assigns each field of the given kinds to the longs/objects carriers:
     * int/uint/float/bool kinds → {@code longs}, everything else →
     * {@code objects}. arrayLens[i] is the array length for ARRAY-kind
     * fields (-1 for non-arrays); arrayElemKinds[i] is the element kind
     * (null for non-arrays).
     */
    public static GoStructDescriptor layout(String typeName, List<String> names, List<GoKind> kinds,
            List<Integer> arrayLens, List<GoKind> arrayElemKinds) {
        if (names.size() != kinds.size() || names.size() != arrayLens.size()
                || names.size() != arrayElemKinds.size()) {
            throw new IllegalArgumentException("names/kinds/arrayLens/arrayElemKinds length mismatch");
        }
        java.util.ArrayList<Field> fields = new java.util.ArrayList<>(names.size());
        int longs = 0;
        int objects = 0;
        for (int i = 0; i < names.size(); i++) {
            GoKind k = kinds.get(i);
            boolean inLongs = k.isIntKind() || k.isFloatKind() || k == GoKind.BOOL;
            fields.add(new Field(names.get(i), k, inLongs, inLongs ? longs++ : objects++,
                    arrayLens.get(i), arrayElemKinds.get(i)));
        }
        return new GoStructDescriptor(typeName, fields);
    }

    /**
     * Legacy layout without array lengths (all -1/null). For call sites that
     * don't have array length info.
     */
    public static GoStructDescriptor layout(String typeName, List<String> names, List<GoKind> kinds) {
        java.util.ArrayList<Integer> lens = new java.util.ArrayList<>(names.size());
        java.util.ArrayList<GoKind> elemKinds = new java.util.ArrayList<>(names.size());
        for (int i = 0; i < names.size(); i++) {
            lens.add(-1);
            elemKinds.add(null);
        }
        return layout(typeName, names, kinds, lens, elemKinds);
    }

    public String typeName() {
        return typeName;
    }

    public List<Field> fields() {
        return fields;
    }

    public int longsCount() {
        return longsCount;
    }

    public int objectsCount() {
        return objectsCount;
    }

    public Field field(int i) {
        return fields.get(i);
    }
}
