package graalgo.frontend;

import com.oracle.truffle.api.frame.VirtualFrame;
import graalgo.values.GoKind;
import graalgo.values.GoStructDescriptor;

/**
 * The {@code nil} identifier in expression position (M4, WS E): currently
 * only reachable as an expression-switch {@code case nil} (the exporter
 * types it with the switch tag's type). Evaluates to the kind's zero
 * value — the nil reference for every nilable kind.
 */
public final class NilNode extends GoExprNode {
    private final GoStructDescriptor structDesc;

    public NilNode(GoKind kind, GoStructDescriptor structDesc) {
        super(kind);
        this.structDesc = structDesc;
    }

    @Override
    public Object executeObject(VirtualFrame frame) {
        return Boxing.zero(kind(), structDesc);
    }
}
