module graalgo-frontend

go 1.27
